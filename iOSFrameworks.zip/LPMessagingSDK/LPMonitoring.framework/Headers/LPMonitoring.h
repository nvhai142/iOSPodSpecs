//
//  Monitoring.h
//  Monitoring
//
//  Created by Nimrod Shai on 12/30/15.
//  Copyright © 2015 Udi Dagan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Monitoring.
FOUNDATION_EXPORT double MonitoringVersionNumber;

//! Project version string for Monitoring.
FOUNDATION_EXPORT const unsigned char MonitoringVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Monitoring/PublicHeader.h>


