//
//  LPAMS.h
//  LPAMS
//
//  Created by Nimrod Shai on 12/30/15.
//  Copyright © 2015 Udi Dagan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AMS.
FOUNDATION_EXPORT double AMSVersionNumber;

//! Project version string for AMS.
FOUNDATION_EXPORT const unsigned char AMSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AMS/PublicHeader.h>


